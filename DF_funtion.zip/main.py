import apache_beam as beam
from apache_beam.runners.dataflow import DataflowRunner
from apache_beam.options.pipeline_options import PipelineOptions
from apache_beam.dataframe.io import read_csv, to_csv
from apache_beam.dataframe import expressions as exp
from apache_beam.io import ReadFromText, WriteToText

import functions_framework
import re


@functions_framework.cloud_event
def start_dataflow_process(cloud_event): 
    def generate_valid_job_name(file_name):
        cleaned_name = re.sub(r'[^a-z0-9]', '_', file_name.lower())
        if not cleaned_name[0].isalpha():
            cleaned_name = 'a' + cleaned_name[1:]
        if not cleaned_name[-1].isalnum():
            cleaned_name = cleaned_name[:-1] + 'z'
        if not cleaned_name:
            cleaned_name = 'default_job_name'
        cleaned_name = cleaned_name.replace('_', '')
        return cleaned_name
    
    
    data = cloud_event.data
    file_name = data['name']
    bucket_name = data['bucket']
    output_bucket='final_5333'
    input_bucket='landing_5333'
    output_prefix='Out_'

    
    # Check if the keyword 'input' is present in the file name
    if 'input' not in file_name.lower():
        print(f"File {file_name} does not contain the keyword 'input'. Exiting.")
        return
    
    print(f"File: {file_name}, Bucket: {bucket_name}")
      
    PROJECT_ID='planar-depth-403402'
    job_name= generate_valid_job_name(file_name)
    JOB_NAME=job_name
    TEMP_DIR=f'gs://{output_bucket}/{job_name}/temp'
    STAGING_LOCATION =f'gs://{output_bucket}/{job_name}/staging'
    REGION='us-south1'
    input_files = f'gs://{input_bucket}/{file_name}'

    
    output_file = f'gs://{output_bucket}/{output_prefix}{file_name}'

    beam_options = PipelineOptions(
        project = PROJECT_ID,
        region = REGION,
        temp_location = TEMP_DIR,
        staging_location = STAGING_LOCATION,
        job_name = JOB_NAME,
        num_workers=2)
    column_name='reads'
    # Create a Pipeline using the options
    p = beam.Pipeline(options=beam_options)

    # Read CSV file
    input_pcollection = (
        p | 'ReadCSV' >> ReadFromText(input_files)
    )

    # Calculate mean and std
    mean_and_std = (
        input_pcollection
        | 'ExtractReads' >> beam.Map(lambda line: {'reads': float(line.split(',')[1])})
        | 'CalculateMeanAndStd' >> beam.CombineGlobally(
            beam.combiners.MeanCombineFn(),
            beam.combiners.CountCombineFn(),
            beam.combiners.MeanCombineFn()
        )
    )

    mean, _, std = mean_and_std

    # Process elements
    output_pcollection = (
        input_pcollection
        | 'ProcessElements' >> beam.Map(
            lambda element: process_element(element, mean, std)
        )
    )

    # Write the results to a temporary file
    temp_output = tempfile.NamedTemporaryFile(delete=False)
    output_pcollection | 'WriteCSV' >> WriteToText(temp_output.name)

    # Run the pipeline
    result = p.run()
    result.wait_until_finish()

    # Move the temporary file to the desired output location
    os.rename(temp_output.name, output_file)
