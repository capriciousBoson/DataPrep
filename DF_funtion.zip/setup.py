# setup.py

import setuptools

setuptools.setup(
    name='my-beam-pipeline',
    version='0.1',
    packages=setuptools.find_packages(),
    install_requires=[
        # 'apache-beam[gcp]==2.34.0',
        'functions-framework==3.*',
        "google-cloud-tasks==2.2.0",
        "google-cloud-pubsub>=0.1.0",
        "google-cloud-storage==1.39.0",
        "google-cloud-bigquery==2.6.2",
        "google-cloud-secret-manager==2.0.0",
        "google-api-python-client==2.3.0",
        "oauth2client==4.1.3", # removed apache-beam[gcp]>=2.20.0
        "wheel>=0.36.2"
    ],
)